package com.gtappdevelopers.wallpaperapp;

import android.graphics.Bitmap;

public class VideoModal {
    private Bitmap thumbNailBitMap;
    private String videoUrl;

}
